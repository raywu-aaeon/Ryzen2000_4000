from MasterScript import ami
ami.memblock('0xFFB1F9D0',8,4)
