import string
from MasterScript import *

def cpuid():
	cpuInfoDump=ami.cpuDump()
	if(cpuInfoDump==None):
		ami.printf("Unable to get Cpuinfo..\\n")
		return False
	ami.printf("Recieved CpuDump from AMIDebugger\\n")
	brandId=[]
	cpumfname=[]
	versionnumber=[]
	cache=[]
	address=[]

	brandId[0:49]=cpuInfoDump[0:49]
	cpumfname[0:12]=cpuInfoDump[49:61]
	versionnumber[0:4]=cpuInfoDump[61:65]
	cache[0:4]=cpuInfoDump[65:69]
	address[0:2]=cpuInfoDump[69:71]

	brandName= ''.join(map(chr,brandId))
	brandName = filter(lambda x: x in string.printable, brandName)
	
	ProcessorName=""
	for item in cpumfname:
		ProcessorName=ProcessorName+chr(item)


	
	i1=versionnumber[0]&0xff
	i2=versionnumber[1]&0xff
	i3=versionnumber[2]&0xff
	i4=versionnumber[3]&0xff
	
	
	CPUVersionNo=i4
	CPUVersionNo=(long(CPUVersionNo)<<8) | i3
	CPUVersionNo=(long(CPUVersionNo)<<8) | i2
	CPUVersionNo=((CPUVersionNo<<8) | i1) & 0x00000000FFFFFFFF


	familyId=AndWith(CPUVersionNo,0x00000f00)
	familyId=ShiftRight(familyId,8)


	model=AndWith(CPUVersionNo,0x000000f0)
	model=ShiftRight(model,4)
	
	extmodel=AndWith(CPUVersionNo, 0x000f0000);
	extmodel=ShiftRight(extmodel, 16);
	
	extfamilyid=AndWith(CPUVersionNo, 0x0ff00000)
	extfamilyid=ShiftRight(extfamilyid, 20)
	
	StepingId=AndWith(CPUVersionNo, 0x0000000f);
	
	
	tempbytes=cache[2] & 0x00000000000000FF
	tempbytes1=cache[3]
	tempbytes1=(long(tempbytes1)<<8)&  0x000000000000FFFF
	cache_size=tempbytes | tempbytes1 
	
	
	tempCacheAsso=cache[1]	
	cache_asso=tempCacheAsso & 0x00000000000000FF
	cache_asso= AndWith(cache_asso, 0x000000F0)
	cache_asso=ShiftRight(cache_asso, 4)
	
	tempCacheln=cache[0]
	
	
	tempAddPhyical=address[0]
	tempAddVir=address[1]
	
	
					
	address_phy=(tempAddPhyical) & 0x00000000000000FF
	address_vir=(tempAddVir) & 0x00000000000000FF
	
	
			
	StepingId=AndWith(CPUVersionNo, 0x0000000F);
	
	
	ami.printf("\nProcessor\n")
	ami.printf("	ProcessorName %s\n",ProcessorName)
	ami.printf("	Brand ID.....%s\n",brandName)
	ami.printf("	Version.....%x \n",CPUVersionNo)
	ami.printf("	Family.....%d\n",familyId)
	ami.printf("	Model.....%d\n",model)
	ami.printf("	Stepping.....%d\n",StepingId)
	ami.printf("	Ext.Family.....%d\n",extfamilyid)
	ami.printf("	Ext.Model.....%d\n",extmodel)
	ami.printf("Cache\n")
	ami.printf("	Size in KBytes.....%d\n",cache_size)
	ami.printf("	Descriptor no.ways to asscoicative.....%d ",cache_asso)
	ami.printf(" Line size in bytes %d\n",tempCacheln)
	ami.printf("Address\n")
	ami.printf("	VirtualMemoryBits.....%d\n",address_vir)
	ami.printf("	PhysicaAddressBits.....%d\n",address_phy)
	


def AndWith(value,withvalue):
	value=value & withvalue
	return value
	
def ShiftRight(value,bits):
	return value>>bits


