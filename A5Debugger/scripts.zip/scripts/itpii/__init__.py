from MasterScript import itp
from datatypes import BitData

# Map BitData member under itpii package
BitData = datatypes.BitData
def baseaccess():
    return itp
def printf(format,*args):
	itp.printf(format,*args)
def Address(self,_add,typ=None):
	if type(_add)!=str:
		return hex(_add)
	else:
		return _add
class Addresstype:
	implied=0
	linear=1
	physical=2
	guestphysical=3
	twofieldvirtual=4
	threefieldvirtual=5
	onefieldcodevirtual=6
	onefielddatavirtual=7
	onefieldstackvirtual=8
AddressType=Addresstype()
