from MasterScript import *
def pciinfo():
    pcilist = ami.PCIList()
    index=0
    for index in range(0,len(pcilist)):
        temp = pcilist[index].split(',')
        bus = int(temp[0].replace('B',''),16)
        device =int(temp[1].replace('D',''),16)
        fun = int(temp[2].replace('F',''),16)
        VendorID=int(temp[3],16)
        DeviceID=int(temp[4],16)
        print("~ Bus = %s ; Dev = %s ; fun = %s "%(hex(bus),hex(device),hex(fun)))
        baseClassCode = ami.pci_config(bus,device,fun,0x0b,1)
        subClassCode = ami.pci_config(bus,device,fun,0x0a,1)
        progIF = ami.pci_config(bus,device,fun,0x09,1)
        pci_Detail(int(baseClassCode),int(subClassCode),int(progIF))
        print("~        VendorID = %x ; DeviceID = %x  \\n"%(VendorID,DeviceID))

def pci_Detail(baseClassCode,subClassCode,progIF):
    if baseClassCode == 0x00:
        if subClassCode == 0x01 and progIF ==0x01:
            print ("~ VGA-compatible device\\n")
        else:
            print ("~ Other than VGA-device\\n")
    elif baseClassCode == 0x01:
        massStoragecontroller(subClassCode,progIF)
    elif baseClassCode == 0x02:
        networkController(subClassCode,progIF)
    elif baseClassCode == 0x03:
        displayController(subClassCode,progIF)
    elif baseClassCode == 0x04:
        multiMediaDevices(subClassCode,progIF)
    elif baseClassCode == 0x05:
        memoryController(subClassCode,progIF)
    elif baseClassCode == 0x06:
        bridgeDevices(subClassCode,progIF)
    elif baseClassCode == 0x07:
        print ("~ Simple communication controller\\n")
    elif baseClassCode == 0x08:
        basicSystemPeripheral(subClassCode,progIF)
    elif baseClassCode == 0x09:
        inputDevices(subClassCode,progIF)
    elif baseClassCode == 0x0c:
        SerialBusController(subClassCode,progIF)
    elif baseClassCode == 0x11:
        if subClassCode == 0x00 and progIF ==0x00:
            print ("~ Data Acquisition and Signal Processing Controllers-DPIO modules.\\n")
        else:
            print ("~ Data Acquisition and Signal Processing Controllers - Other\\n")
    else:
        print("~undefined\\n")
    print ("~        Class code = %x SubClass code = %x Prog IF = %x \\n"%(baseClassCode,subClassCode,progIF))

def SerialBusController(subClassCode,progIF):
    print ("~ Serial Bus Controller - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~ Firewire (IEEE 1394)\\n")
    elif subClassCode == 0x00 and progIF ==0x10:
        print ("~ IEEE 1394 using 1394 OpenHCI spec\\n")
    elif subClassCode == 0x01 and progIF ==0x00:
        print ("~ ACCESS bus.\\n")
    elif subClassCode == 0x02 and progIF ==0x00:
        print ("~ SSA (Serial Storage Architecture)\\n")
    elif subClassCode == 0x03 and progIF ==0x00:
        print ("~ USB controller using Universal Host Controller spec\\n")
    elif subClassCode == 0x03 and progIF ==0x10:
        print ("~ USB controller using Open Host Controller spec\\n")
    elif subClassCode == 0x03 and progIF ==0x80:
        print ("~ USB controller with no specific programming interface.\\n")
    elif subClassCode == 0x03 and progIF ==0xfe:
        print ("~ USB device (not Host Controller)\\n")
    elif subClassCode == 0x04 and progIF ==0x00:
        print ("~ Fibre Channel\\n")
    elif subClassCode == 0x05 and progIF ==0x00:
        print ("~ SMBus (System Management Bus)\\n")
    else:
        print ("~ Other bridge type\\n")

def displayController(subClassCode,progIF):
    print ("~ display Controller - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~   VGA compatible controller\\n")
    elif subClassCode == 0x00 and progIF ==0x01:
        print ("~ 8514-compatible controller\\n")
    elif subClassCode == 0x01 and progIF ==0x00:
        print ("~ XGA controller\\n")
    elif subClassCode == 0x02 and progIF ==0x00:
        print ("~ 3D controller\\n")
    else:
        print ("~ Other display controller.\\n")

def networkController(subClassCode,progIF):
    print ("~ network Controller - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~ Ethernet controller\\n")
    elif subClassCode == 0x01 and progIF ==0x00:
        print ("~ Token ring controller\\n")
    elif subClassCode == 0x02 and progIF ==0x00:
        print ("~ FDDI controller.\\n")
    elif subClassCode == 0x03 and progIF ==0x00:
        print ("~ ATM controller\\n")
    elif subClassCode == 0x04 and progIF ==0x00:
        print ("~ ISDN controller\\n")
    else:
        print ("~ Other network controller\\n")
    
def multiMediaDevices(subClassCode,progIF):
    print ("~ multiMedia Devices - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~ Video device\\n")
    elif subClassCode == 0x01 and progIF ==0x00:
        print ("~ Audio device\\n")
    elif subClassCode == 0x02 and progIF ==0x00:
        print ("~ Computer Telephony device\\n")
    else:
        print ("~ Other multimedia device.\\n")

def memoryController(subClassCode,progIF):
    print ("~ memory Controller - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~   RAM memory controller\\n")
    elif subClassCode == 0x00 and progIF ==0x01:
        print ("~ Flash memory controller\\n")
    else:
        print ("~ Other Memory controller device.\\n")

def massStoragecontroller(subClassCode,progIF):
    print ("~ mass Storage controller - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~ SCSI controller\\n")
    elif subClassCode == 0x01:
        print ("~ IDE controller\\n")
    elif subClassCode == 0x02 and progIF ==0x00:
        print ("~ Floppy disk controller.\\n")
    elif subClassCode == 0x03 and progIF ==0x00:
        print ("~ IPI controller\\n")
    elif subClassCode == 0x04 and progIF ==0x00:
        print ("~ RAID controller\\n")
    elif subClassCode == 0x05 and progIF ==0x20:
        print ("~ ATA controller with single DMA\\n")
    elif subClassCode == 0x05 and progIF ==0x30:
        print ("~ ATA controller with chained DMA\\n")
    else:
        print ("~ Other mass storage controller\\n")

def bridgeDevices(subClassCode,progIF):
    print ("~ bridge Devices - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~ Host/PCI bridge\\n")
    elif subClassCode == 0x01 and progIF ==0x00:
        print ("~ PCI/ISA bridge\\n")
    elif subClassCode == 0x02 and progIF ==0x00:
        print ("~ PCI/EISA bridge.\\n")
    elif subClassCode == 0x03 and progIF ==0x00:
        print ("~ PCI/Micro Channel bridge\\n")
    elif subClassCode == 0x04 and progIF ==0x00:
        print ("~ PCI/PCI bridge.\\n")
    elif subClassCode == 0x04 and progIF ==0x01:
        print ("~ Subtractive decode PCI-to-PCI bridge.\\n")
    elif subClassCode == 0x05 and progIF ==0x00:
        print ("~ PCI/PCMCIA bridge.\\n")
    elif subClassCode == 0x06 and progIF ==0x00:
        print ("~ PCI/NuBus bridge.\\n")
    elif subClassCode == 0x07 and progIF ==0x00:
        print ("~ PCI/CardBus bridge.\\n")
    else:
        print ("~ Other bridge type\\n")

def basicSystemPeripheral(subClassCode,progIF):
    print ("~ Base System Peripheral - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~ Generic 8259 PIC\\n")
    elif subClassCode == 0x00 and progIF ==0x01:
        print ("~ ISA PIC\\n")
    elif subClassCode == 0x00 and progIF ==0x02:
        print ("~ EISA PIC.\\n")
    elif subClassCode == 0x00 and progIF ==0x10:
        print ("~ IO APIC\\n")
    elif subClassCode == 0x00 and progIF ==0x20:
        print ("~ IO(x) APIC interrupt controller.\\n")
    elif subClassCode == 0x01 and progIF ==0x00:
        print ("~ Generic 8237 DMA controller.\\n")
    elif subClassCode == 0x01 and progIF ==0x01:
        print ("~ ISA DMA controller\\n")
    elif subClassCode == 0x01 and progIF ==0x02:
        print ("~ EISA DMA controller.\\n")
    elif subClassCode == 0x02 and progIF ==0x00:
        print ("~ Generic 8254 system timer.\\n")
    elif subClassCode == 0x02 and progIF ==0x01:
        print ("~ ISA system timer\\n")
    elif subClassCode == 0x02 and progIF ==0x02:
        print ("~ EISA system timers (two timers)\\n")
    elif subClassCode == 0x03 and progIF ==0x00:
        print ("~ Generic RTC controller\\n")
    elif subClassCode == 0x03 and progIF ==0x01:
        print ("~ ISA RTC controller\\n")
    elif subClassCode == 0x04 and progIF ==0x00:
        print ("~ Generic PCI Hot-Plug controller\\n")
    else:
        print ("~ Other system peripheral\\n")

def inputDevices(subClassCode,progIF):
    print ("~ Input Devices - ")
    if subClassCode == 0x00 and progIF ==0x00:
        print ("~ Keyboard controller\\n")
    elif subClassCode == 0x00 and progIF ==0x00:
        print ("~ Digitizer (pen).\\n")
    elif subClassCode == 0x01 and progIF ==0x00:
        print ("~ Mouse controller\\n")
    elif subClassCode == 0x02 and progIF ==0x00:
        print ("~ Scanner controller\\n")
    elif subClassCode == 0x03 and progIF ==0x00:
        print ("~ Generic gameport controller.\\n")
    elif subClassCode == 0x04 and progIF ==0x00:
        print ("~ Gameport controller.\\n")
    else:
        print ("~   Other input controller\\n")
